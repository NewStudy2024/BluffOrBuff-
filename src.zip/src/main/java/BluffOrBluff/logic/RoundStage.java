package BluffOrBluff.logic;

public enum RoundStage {
    PRE_FLOP,
    FLOP,
    TURN,
    RIVER,
    SHOWDOWN
}