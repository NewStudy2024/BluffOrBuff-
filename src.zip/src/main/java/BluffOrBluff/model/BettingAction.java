package BluffOrBluff.model;

public enum BettingAction {
    FOLD,
    CALL,
    RAISE,
    CHECK,
    ALL_IN
}
